<?php

class MDN_OrderPreparation_Block_PickupDeliveryOrders_PickupForm extends Mage_Core_Block_Template
{

}