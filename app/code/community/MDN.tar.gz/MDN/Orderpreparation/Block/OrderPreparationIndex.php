<?php

/**
 * Block pour l'index de la page de pr�paration de commandes
 *
 */
class MDN_OrderPreparation_Block_OrderPreparationIndex extends Mage_Core_Block_Template
{

}