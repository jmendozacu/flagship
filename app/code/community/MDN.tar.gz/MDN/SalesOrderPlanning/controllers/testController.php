<?php
class MDN_SalesOrderPlanning_testController extends Mage_Core_Controller_Front_Action
{
	public function testAction()
	{
		die('totot');
	}
}