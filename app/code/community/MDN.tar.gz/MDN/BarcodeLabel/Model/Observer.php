<?php
/**
 * Magento
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 *
 * @copyright  Copyright (c) 2009 Maison du Logiciel (http://www.maisondulogiciel.com)
 * @author : Olivier ZIMMERMANN
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */
class MDN_BarcodeLabel_Model_Observer extends Mage_Core_Model_Abstract
{
	
	/**
	 * ***********************************************************************************************************************************
	 * ***********************************************************************************************************************************
	 * TRIGGERS
	 * ***********************************************************************************************************************************
	 * ***********************************************************************************************************************************
	 */
	
	/**
	 * Method called each time an object is saved (and changed :)
	 *
	 */
	public function model_save_after(Varien_Event_Observer $observer)
	{

		$object = $observer->getEvent()->getObject(); 
				
		$objectType = mage::helper('BarcodeLabel')->getObjectType($object);
                
                // detect if the module saved is a product
                if( $objectType == "catalog/product"){
                    
                    if( $object->getId() != $object->getOrigData('entity_id') ){
                    //echo "produit"; die('la');
                    
                        // check if barcode is already done
                        $barcodeAttributeName = Mage::helper('BarcodeLabel')->getBarcodeAttribute();
                        $barcode = $object->getData($barcodeAttributeName);
                        
                        if( empty($barcode) ){
                            
                            // generate barcode
                            Mage::helper('BarcodeLabel/Generation')->storeBarcode($object->getId());
                             
                        }
                        
                       
                    }
             
                }
                
                //die('toto');
		
	}
        
        public function addMassAction($observer)
        {
            $block = $observer->getEvent()->getBlock();
            if(get_class($block) =='Mage_Adminhtml_Block_Widget_Grid_Massaction'
                && $block->getRequest()->getControllerName() == 'catalog_product')
            {  
                
                $block->addItem('BarcodeLabel', array(
                    'label' => 'Print Label',
                    'url' => Mage::app()->getStore()->getUrl('BarcodeLabel/Admin/printSelectedProductLabel'),
                ));

            }
        }
        

	/**
         ******************************************************************************************************************************** 
         */
	
}