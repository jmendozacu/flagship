<?php

class MDN_Purchase_Model_Reports_Mysql4_Product_Ordered_Collection extends Mage_Reports_Model_Mysql4_Product_Ordered_Collection
{
	/*
    protected function _joinFields($from = '', $to = '')
    {
        $this->addAttributeToSelect('*')
            ->addOrderedQty($from, $to)
            ->setOrder('mage_ordered_qty', 'desc');

        return $this;
    }
    */
}