<?php

class MDN_Scanner_Block_BarcodeComparison_Index extends Mage_Adminhtml_Block_Widget_Form
{
}