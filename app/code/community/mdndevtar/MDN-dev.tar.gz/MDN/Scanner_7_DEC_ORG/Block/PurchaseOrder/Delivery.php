<?php

class MDN_Scanner_Block_PurchaseOrder_Delivery extends Mage_Core_Block_Template
{
	
}