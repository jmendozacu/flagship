<?php


class MDN_Organizer_Block_Dashboard extends Mage_Core_Block_Template
{
	
}