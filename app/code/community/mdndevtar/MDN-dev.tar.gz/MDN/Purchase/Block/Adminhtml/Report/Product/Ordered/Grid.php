<?php

class MDN_Purchase_Block_Adminhtml_Report_Product_Ordered_Grid extends Mage_Adminhtml_Block_Report_Product_Ordered_Grid
{
	
}
