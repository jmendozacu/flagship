<?php

//###############################################################

// DO NOT REMOVE THIS FILE !!!!!!!!!

//###############################################################


class MDN_Purchase_Model_Catalog_Product  extends MDN_AdvancedStock_Model_Catalog_Product
{
	//not used but required as magento keeps model class name in the database	
}