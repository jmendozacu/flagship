<?php

//###############################################################

// DO NOT REMOVE THIS FILE !!!!!!!!!

//###############################################################


class MDN_Purchase_Model_CatalogInventory_Stock_Item extends MDN_AdvancedStock_Model_CatalogInventory_Stock_Item
{
	//not used but required as magento keeps model class name in the database	
}