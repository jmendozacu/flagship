<?php

/**
 * Magento
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 *
 * @copyright  Copyright (c) 2009 Maison du Logiciel (http://www.maisondulogiciel.com)
 * @author : Olivier ZIMMERMANN
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */
class MDN_Purchase_Model_Order extends Mage_Core_Model_Abstract {

    private $_products = null;
    private $_currency = null;
    private $_supplier = null;
    private $_weight = null;

    //Purchase order statuses
    const STATUS_NEW = 'new';
    const STATUS_INQUIRY = 'inquiry';
    const STATUS_WAITING_FOR_SUPPLIER = 'waiting_for_supplier';
    const STATUS_WAITING_FOR_PAYMENT = 'waiting_for_payment';
    const STATUS_WAITING_FOR_DELIVERY = 'waiting_for_delivery';
    const STATUS_COMPLETE = 'complete';

    public function _construct() {
        parent::_construct();
        $this->_init('Purchase/Order');
    }

    //*******************************************************************************************************************************************
    //*******************************************************************************************************************************************
    // Related objects / collection
    //*******************************************************************************************************************************************
    //*******************************************************************************************************************************************

    /**
     * Return supplier
     *
     */
    public function getSupplier() {
        if ($this->_supplier == null) {
            $this->_supplier = mage::getModel('Purchase/Supplier')->load($this->getpo_sup_num());
        }
        return $this->_supplier;
    }

    /**
     *
     *
     */
    public function getStockMovements() {
        $collection = mage::getModel('AdvancedStock/StockMovement')
                        ->getCollection()
                        ->addFieldToFilter('sm_po_num', $this->getId());

        return $collection;
    }

    /**
     * return statuses
     *
     */
    public function getStatuses() {
        $retour = array();
        $retour[MDN_Purchase_Model_Order::STATUS_NEW] = mage::helper('purchase')->__('New');
        $retour[MDN_Purchase_Model_Order::STATUS_INQUIRY] = mage::helper('purchase')->__('Inquiry');
        $retour[MDN_Purchase_Model_Order::STATUS_WAITING_FOR_PAYMENT] = mage::helper('purchase')->__('Waiting for payment');
        $retour[MDN_Purchase_Model_Order::STATUS_WAITING_FOR_SUPPLIER] = mage::helper('purchase')->__('Waiting for supplier');
        $retour[MDN_Purchase_Model_Order::STATUS_WAITING_FOR_DELIVERY] = mage::helper('purchase')->__('Waiting for delivery');
        $retour[MDN_Purchase_Model_Order::STATUS_COMPLETE] = mage::helper('purchase')->__('Complete');
        return $retour;
    }

    /**
     * Return products
     *
     */
    public function getProducts() {
        if ($this->_products == null) {
            //load product collection (and add small_image and product_price attributes)
            $this->_products = mage::getModel('Purchase/OrderProduct')
                            ->getCollection()
                            ->addFieldToFilter('pop_order_num', $this->getId())
                            ->join('catalog/product',
                                    'entity_id=pop_product_id')
                            ->join('Purchase/CatalogProductDecimal',
                                    '`catalog/product`.entity_id=`Purchase/CatalogProductDecimal`.entity_id and `Purchase/CatalogProductDecimal`.store_id = 0 and `Purchase/CatalogProductDecimal`.attribute_id = ' . mage::getModel('Purchase/Constant')->GetProductPriceAttributeId(),
                                    array('sale_price' => 'value'));

            //add small image
            $smallImageTableName = mage::getModel('Purchase/Constant')->getTablePrefix() . 'catalog_product_entity_varchar';
            $this->_products->getSelect()->joinLeft($smallImageTableName,
                    '`catalog/product`.entity_id=`' . $smallImageTableName . '`.entity_id and `' . $smallImageTableName . '`.store_id = 0 and `' . $smallImageTableName . '`.attribute_id = ' . mage::getModel('Purchase/Constant')->GetProductSmallImageAttributeId(),
                    array('small_image' => 'value'));
        }
        return $this->_products;
    }

    /**
     * Reset internal collection
     *
     */
    public function resetProducts() {
        $this->_products = null;
    }

    //*******************************************************************************************************************************************
    //*******************************************************************************************************************************************
    // Price functions
    //*******************************************************************************************************************************************
    //*******************************************************************************************************************************************

    /**
     * Return total excluding taxes
     *
     */
    public function getTotalHt() {
        $retour = 0;
        foreach ($this->getProducts() as $item) {
            $retour += round($item->getRowTotal(), 2);
        }

        //rajoute les frais
        $retour += round($this->getShippingAmountHt(), 2);
        $retour += round($this->getZollAmountHt(), 2);
        return $retour;
    }

    public function getProductTotalBase() {
        $orderAmount = 0;
        foreach ($this->getProducts() as $item) {
            $orderAmount += round($item->getRowTotal_base(), 2);
        }
        return $orderAmount;
    }

    /**
     * Return total including taxes
     *
     */
    public function getTotalTtc() {
        $retour = 0;
        foreach ($this->getProducts() as $item) {
            $retour += round($item->getRowTotalWithTaxes(), 2);
        }
        //rajoute les fdp
        $retour += round($this->getShippingAmountTtc(), 2);
        $retour += round($this->getZollAmountTtc(), 2);
        return $retour;
    }

    /**
     *
     *
     */
    public function getTaxAmount() {
        return $this->getTotalTtc() - $this->getTotalHt();
    }

    /**
     *
     *
     */
    public function getShippingAmountHt() {
        return $this->getpo_shipping_cost();
    }

    /**
     *
     *
     */
    public function getShippingAmountTtc() {
        $value = $this->getpo_shipping_cost() * (1 + $this->getpo_tax_rate() / 100);
        return round($value, 2);
    }

    /**
     *
     *
     */
    public function getZollAmountHt() {
        return $this->getpo_zoll_cost();
    }

    /**
     *
     *
     */
    public function getZollAmountTtc() {
        $value = $this->getpo_zoll_cost() * (1 + $this->getpo_tax_rate() / 100);
        return round($value, 2);
    }

    /**
     *
     *
     */
    public function getCurrency() {
        if ($this->_currency == null) {
            $this->_currency = mage::getModel('directory/currency')->load($this->getpo_currency());
        }
        return $this->_currency;
    }

    /**
     *
     *
     */
    public function getEuroCurrency() {
        return mage::getModel('directory/currency')->load('EUR');
    }

    /**
     * Return order weight
     */
    public function getWeight() {
        if ($this->_weight == null) {
            $this->_weight = 0;
            foreach ($this->getProducts() as $item) {
                $this->_weight += $item->getRowWeight();
            }
        }
        return $this->_weight;
    }

    //*******************************************************************************************************************************************
    //*******************************************************************************************************************************************
    // Function to update related datas
    //*******************************************************************************************************************************************
    //*******************************************************************************************************************************************

    /**
     *
     *
     */
    public function updateProductSupplierAssociation($productId = null) {
        //parcourt les produits
        foreach ($this->getProducts() as $item) {
            //if a product id is set and current product doesn't match, continue
            if (($productId != null) && ($productId != $item->getpop_product_id()))
                continue;

            //Verifie si l'association existe d�ja
            $ProductSupplier = null;
            $Collection = mage::getModel('Purchase/ProductSupplier')
                            ->getCollection()
                            ->addFieldToFilter('pps_product_id', $item->getpop_product_id())
                            ->addFieldToFilter('pps_supplier_num', $this->getpo_sup_num());

            //Si existe pas
            if (sizeof($Collection) == 0) {
                $ProductSupplier = mage::getModel('Purchase/ProductSupplier');
                $ProductSupplier->setpps_product_id($item->getpop_product_id());
                $ProductSupplier->setpps_supplier_num($this->getpo_sup_num());
            } else {
                //Si existe on recupere
                foreach ($Collection as $item2) {
                    $ProductSupplier = $item2;
                    break;
                }
            }

            //met a jour (si date est inf�rieure a la date de notre commande)
            if ((strtotime($this->getpo_date()) >= strtotime($ProductSupplier->getpps_last_order_date())) || ($ProductSupplier->getpps_last_order_date() == null)) {
                if ($item->getpop_supplier_ref() != '')
                    $ProductSupplier->setpps_reference($item->getpop_supplier_ref());
                $ProductSupplier->setpps_last_order_date($this->getpo_date());
                
                $ProductSupplier->setpps_last_price($item->getUnitPriceWithExtendedCosts_base());
                $ProductSupplier->setpps_last_unit_price($item->getpop_price_ht_base());
                $ProductSupplier->setpps_last_unit_price_supplier_currency($item->getpop_price_ht());

                //save
                $ProductSupplier->save();
            }
        }
    }

    /**
     *
     *
     */
    public function dispatchExtendedCosts() {
        //get repartition method
        $RepartitionMode = Mage::getStoreConfig('purchase/purchase_order/cost_repartition_method');

        //calculate amounts
        $TotalProductHt = 0;
        $TotalProductHt_base = 0;
        $TotalQty = 0;
        foreach ($this->getProducts() as $item) {

            $TotalProductHt += $item->getRowTotal();
            $TotalProductHt_base += $item->getRowTotal_base();
            $TotalQty += $item->getpop_qty();
        }

        if ($TotalProductHt == 0)
            return;

        //Dispatch extended costs
        $TotalExtendedCosts = $this->getpo_shipping_cost() + $this->getpo_zoll_cost();
        $TotalExtendedCosts_base = $this->getpo_shipping_cost_base() + $this->getpo_zoll_cost_base();
        foreach ($this->getProducts() as $item) {
            switch ($RepartitionMode) {
                case 'by_qty':
                    $item->setpop_extended_costs($TotalExtendedCosts / $TotalQty);
                    $item->setpop_extended_costs_base($TotalExtendedCosts_base / $TotalQty);
                    $item->save();
                    break;
                case 'by_amount':
                    $item->setpop_extended_costs($TotalExtendedCosts / $TotalProductHt * ($item->getpop_price_ht() + $item->getpop_eco_tax()));
                    $item->setpop_extended_costs_base($TotalExtendedCosts_base / $TotalProductHt_base * ($item->getpop_price_ht_base() + $item->getpop_eco_tax_base()));
                    $item->save();
                    break;
                default:
                    throw new Exception('Repartition Cost Method not set');
            }
        }
    }

    /**
     *
     *
     */
    public function UpdateProductsDeliveryDate($productId = null) {
        //plan update product delivery date for each product in order
        foreach ($this->getProducts() as $item) {
            if (($productId != null) && ($item->getpop_product_id() != $productId))
                continue;

            //plan task
            mage::helper('BackgroundTask')->AddTask('Update product delivery date for product #' . $item->getpop_product_id(),
                    'purchase',
                    'updateProductDeliveryDate',
                    $item->getpop_product_id()
            );
        }
    }

    /**
     * Update costs for every products
     *
     */
    public function UpdateProductsCosts($productId = null) {
        if (Mage::getStoreConfig('purchase/purchase_order/store_product_cost')) {
            if ($this->getpo_status() == MDN_Purchase_Model_Order::STATUS_COMPLETE) {
                foreach ($this->getProducts() as $item) {
                    if (($productId != null) && ($item->getpop_product_id() != $productId))
                        continue;

                    //plan product cost update
                    $productId = $item->getpop_product_id();
                    mage::helper('BackgroundTask')->AddTask('Update cost for product #' . $productId,
                            'purchase/Product',
                            'updateProductCost',
                            $productId
                    );
                }
            }
        }
    }

    /**
     *
     *
     */
    public function UpdateProductsWaitingForDeliveryQty($productId = null) {
        foreach ($this->getProducts() as $item) {
            if (($productId != null) && ($item->getpop_product_id() != $productId))
                continue;

            //plan task
            mage::helper('BackgroundTask')->AddTask('Update waiting for delivery qty for product #' . $item->getpop_product_id(),
                    'purchase',
                    'updateProductWaitingForDeliveryQty',
                    $item->getpop_product_id()
            );
        }
    }

    /**
     * 
     *
     * @param unknown_type $ProductId
     * @param unknown_type $order
     */
    public function AddProduct($ProductId, $qty = 1) {
        
        $purchaseOrderProduct = $this->getPurchaseOrderItem($ProductId);

        //if product is not present
        if ($purchaseOrderProduct == null) {
            $ProductSupplierModel = mage::getModel('Purchase/ProductSupplier');
            $Product = mage::getModel('catalog/product')->load($ProductId);
            $ref = $this->getSupplier()->getProductReference($ProductId);
            $supplierId = $this->getpo_sup_num();

            //check if product is associated to the supplier (is enabled)
            if (mage::helper('purchase')->requireProductSupplierAssociationToAddProductInPo())
            {
                $productSupplier = mage::getModel('Purchase/ProductSupplier')->getProductForSupplier($ProductId, $supplierId);
                if (!$productSupplier)
                    throw new Exception(mage::helper('purchase')->__('This product (%s) is not associated to the supplier)', $Product->getName()));
            }

            //product price
            $price = 0;
            if (Mage::getStoreConfig('purchase/purchase_order/auto_fill_price'))
            {
                $productSupplier = $ProductSupplierModel->getProductForSupplier($ProductId, $supplierId);
                if ($productSupplier)
                    $price = $productSupplier->getpps_last_unit_price_supplier_currency();
            }
            if (Mage::getStoreConfig('purchase/purchase_order/use_product_cost'))
                $price = $Product->getCost();

            //discount
            $discountLevel = $this->getSupplier()->getProductDiscountLevel($ProductId, $qty);

            $orderProduct = mage::getModel('Purchase/OrderProduct')
                            ->setpop_order_num($this->getId())
                            ->setpop_product_id($ProductId)
                            ->setpop_product_name($Product->getname())
                            ->setpop_qty($qty)
                            ->setpop_supplier_ref($ref)
                            ->setpop_price_ht($price)
                            ->setpop_price_ht_base($price)
                            ->setpop_discount($discountLevel)
                            ->setpop_weight($Product->getweight())
                            ->setpop_tax_rate($this->getPurchaseTaxRate($Product));

            //process packaging (if enabled)
            $packagingHelper = mage::helper('purchase/Product_Packaging');
            if ($packagingHelper->isEnabled()) {
                $purchasePackaging = $packagingHelper->getDefaultPurchasePackaging($ProductId);
                if ($purchasePackaging->getId()) {
                    $packageCount = $purchasePackaging->convertUnitToPackage($qty);
                    $qty = $packageCount * $purchasePackaging->getpp_qty();
                    $orderProduct->setpop_packaging_id($purchasePackaging->getId())
                            ->setpop_packaging_value($purchasePackaging->getpp_qty())
                            ->setpop_packaging_name($purchasePackaging->getpp_name())
                            ->setpop_qty($qty);
                }
            }

            //Save
            $orderProduct->setPurchaseOrder($this);
            $orderProduct->save();

            return $orderProduct;
        } else {
            //if product already belong to the PO, increase qty
            $purchaseOrderProduct->setpop_qty($purchaseOrderProduct->getpop_qty() + $qty)->save();
            return $purchaseOrderProduct;
        }
    }

    /**
     * Return purchase tax rate for product
     *
     */
    private function getPurchaseTaxRate($product) {

        $TaxId = $product->getpurchase_tax_rate();
        if (($TaxId == 0) || ($TaxId == ''))
            $TaxId = $this->getSupplier()->getTaxRate()->getId();
        if (($TaxId == 0) || ($TaxId == ''))
            $TaxId = mage::getStoreConfig('purchase/purchase_order/products_default_tax_rate');

        //recupere et retourne la valeur
        return mage::getModel('Purchase/TaxRates')->load($TaxId)->getptr_value();
    }

    /**
     * Compute deliveries progress
     *
     */
    public function computeDeliveryProgress() {
        $progress = 0;
        $qtyCount = 0;
        $deliveredCount = 0;

        foreach ($this->getProducts() as $item) {
            $qtyCount += $item->getpop_qty();
            $deliveredCount += $item->getpop_supplied_qty();
        }
        if ($qtyCount > 0)
            $progress = $deliveredCount / $qtyCount * 100;
        $this->setpo_delivery_percent($progress)->save();
    }

    /**
     * After save
     *
     */
    protected function _afterSave() {
        parent::_afterSave();

        $statusBeforeSave = $this->getOrigData('po_status');
        $statusAfterSave = $this->getData('po_status');

        if ($statusAfterSave != $statusBeforeSave)
            Mage::dispatchEvent('purchase_order_status_changed', array('purchase_order' => $this));
    }

    /**
     * Before save
     *
     */
    protected function _beforeSave() {
        parent::_beforeSave();

        //update purchase nature if supplier change
        if ($this->getpo_sup_num() != $this->getOrigData('po_sup_num')) {
            $supplier = $this->getSupplier();
            if ($supplier->getId())
                $this->setpo_purchase_nature($supplier->getPurchaseNature());
        }

        //convert shippincost & zollcost to base currency
        $fields = array('po_shipping_cost', 'po_zoll_cost');
        $changeRate = ($this->getpo_currency_change_rate() > 0 ? $this->getpo_currency_change_rate() : 1);
        foreach ($fields as $field) {
            $baseValue = $this->getData($field) / $changeRate;
            $this->setdata($field . '_base', $baseValue);
        }
    }

    //*********************************************************************************************************************************************************************
    //*********************************************************************************************************************************************************************
    // UPDATES
    //*********************************************************************************************************************************************************************
    //*********************************************************************************************************************************************************************

    /**
     * Update datas and associations when order is complete
     *
     */
    public function updateDataWhenComplete() {
        die('updateDataWhenComplete deprecated');
    }

    /*
      public function checkForChangesAndLaunchUpdates()
      {
      //init vars
      $debug = '';
      $shippingCostChanged = ($this->getpo_shipping_cost() != $this->getOrigData('po_shipping_cost'));
      $zollCostChanged = ($this->getpo_zoll_cost() != $this->getOrigData('po_zoll_cost'));
      $statusChanged = ($this->getpo_status() != $this->getOrigData('po_status'));
      $supplyDateChanged = ($this->getpo_supply_date() != $this->getOrigData('po_supply_date'));
      $productAdded = false;
      $productQtyChanged = $this->checkIfProductQtyChanged();
      $productDeleted = false;
      $productPriceChanged = false;
      $deliveredQtyChanged = false;
      $orderStatusChangedToComplete = false;
      $orderStatusChangedFromComplete = false;

      //check if we have to dispatch extended costs
      if ($shippingCostChanged || $zollCostChanged || $productAdded || $productQtyChanged || $productDeleted)
      {
      $this->dispatchExtendedCosts();
      $debug .= 'dispatchExtendedCosts, ';
      }

      //check if we have to update data because order is complete
      if ($this->getpo_status() == MDN_Purchase_Model_Order::STATUS_COMPLETE)
      {
      $this->updateDataWhenComplete();
      $debug .= 'updateDataWhenComplete, ';
      }

      //check if we have to update delivery progress
      if ($productAdded || $productQtyChanged || $productDeleted || $deliveredQtyChanged)
      {
      $this->computeDeliveryProgress();
      $debug .= 'computeDeliveryProgress, ';
      }

      //check if we have to update products delivery date and waiting for delivery qty
      if ($supplyDateChanged && ($this->getpo_status() == MDN_Purchase_Model_Order::STATUS_WAITING_FOR_DELIVERY))
      {
      $this->UpdateProductsDeliveryDate();
      $debug .= 'UpdateProductsDeliveryDate, ';
      }

      //Check if we have to update waiting for delivery qty
      if ($deliveredQtyChanged || $orderStatusChangedToComplete || $orderStatusChangedFromComplete || ($productQtyChanged && ($this->getpo_status() == MDN_Purchase_Model_Order::STATUS_WAITING_FOR_DELIVERY)))
      {
      $this->UpdateProductsWaitingForDeliveryQty();
      $debug .= 'UpdateProductsWaitingForDeliveryQty, ';
      }

      return $debug;
      }
     */

    /**
     * Check if products qty changed
     *
     * @return unknown
     */
    private function checkIfProductQtyChanged() {
        $value = false;

        foreach ($this->getProducts() as $item) {
            if ($item->getpop_qty() != $item->getOrigData('pop_qty'))
                $value = true;
        }

        return $value;
    }

    //*********************************************************************************************************************************************************************
    //*********************************************************************************************************************************************************************
    // MISC
    //*********************************************************************************************************************************************************************
    //*********************************************************************************************************************************************************************

    /**
     *
     *
     */
    public function GenerateOrderNumber() {
        //prefix
        $retour = date('Ymd') . 'BC';

        //Trouve le prochain
        for ($i = 1; $i < 30; $i++) {
            //d�finit le num�ro
            $temp = $retour . $i;

            //Verifie si existe
            $collection = Mage::getModel('Purchase/Order')
                            ->getCollection()
                            ->addFieldToFilter('po_order_id', $temp);

            if (sizeof($collection) == 0)
                return $temp;
        }

        return $retour;
    }

    /**
     * Return a purchase order item for a product id
     *
     * @param unknown_type $productId
     */
    public function getPurchaseOrderItem($productId) {
        foreach ($this->getProducts() as $product) {
            if ($product->getpop_product_id() == $productId)
                return $product;
        }
        return null;
    }

    /**
     * Method to check if product prices are missing
     *
     */
    public function hasMissingPrices() {
        foreach ($this->getProducts() as $item) {
            if ($item->getpop_price_ht() == 0)
                return true;
        }

        return false;
    }

    /**
     * Send order per email to supplier
     *
     */
    public function notifySupplier($msg) {
        //retrieve information
        $email = $this->getSupplier()->getsup_mail();
        if ($email == '')
            return false;
        $cc = Mage::getStoreConfig('purchase/notify_supplier/cc_to');
        $identity = Mage::getStoreConfig('purchase/notify_supplier/email_identity');
        $emailTemplate = Mage::getStoreConfig('purchase/notify_supplier/email_template');

        if ($emailTemplate == '')
            die('Email template is not set (system > config > purchase)');

        //get pdf
        $Attachment = null;
        $pdf = Mage::getModel('Purchase/Pdf_Order')->getPdf(array($this));
        $Attachment = array();
        $Attachment['name'] = mage::helper('purchase')->__('Purchase Order #') . $this->getpo_order_id() . '.pdf';
        $Attachment['content'] = $pdf->render();

        $Attachments = array();
        $Attachments[] = $Attachment;

        //definies datas
        $data = array
            (
            'company_name' => Mage::getStoreConfig('purchase/notify_supplier/company_name'),
            'message' => $msg,
            'order_id' => $this->getpo_order_id()
        );

        //send email
        $translate = Mage::getSingleton('core/translate');
        $translate->setTranslateInline(false);
        Mage::getModel('core/email_template')
                ->setDesignConfig(array('area' => 'adminhtml'))
                ->sendTransactional(
                        $emailTemplate,
                        $identity,
                        $email,
                        '',
                        $data,
                        null,
                        $Attachments);

        //send email to cc
        if ($cc != '') {
            Mage::getModel('core/email_template')
                    ->setDesignConfig(array('area' => 'adminhtml'))
                    ->sendTransactional(
                            $emailTemplate,
                            $identity,
                            $cc,
                            '',
                            $data,
                            null,
                            $Attachments);
        }

        $translate->setTranslateInline(true);
        $this->setpo_supplier_notification_date(date('y-m-d H:i'))->save();

        return true;
    }

    /**
     * Return true if all products are delivered
     *
     */
    public function isCompletelyDelivered() {
        $totalQty = 0;

        foreach ($this->getProducts() as $item) {
            if ($item->getpop_qty() > $item->getpop_supplied_qty())
                return false;
            $totalQty += $item->getpop_qty();
        }

        if ($totalQty > 0)
            return true;
        else
            return false;
    }

    /**
     * Create a delivery
     *
     */
    public function createDelivery($OrderProductItem, $qty, $date, $description, $targetWarehouse, $toggleOrderStatus = false) {
        //init vars
        $productId = $OrderProductItem->getpop_product_id();
        $purchasedQty = $qty;

        //if packaging is enabled, edit qty to match to default packagings
        if (mage::helper('purchase/Product_Packaging')->isEnabled()) {
            $purchasedQty = $qty * $OrderProductItem->getpop_packaging_value();
            $qty = mage::helper('purchase/Product_Packaging')->convertToSalesUnit($productId, $purchasedQty);
        }

        //create stock movement
        $stockMovementModel = mage::getModel('AdvancedStock/StockMovement');
        $additionalData = array('sm_po_num' => $this->getId(), 'sm_type' => 'supply');
        $stockMovementModel->validateStockMovement($productId, null, $targetWarehouse, $qty);
        $stockMovementModel->createStockMovement($productId, null, $targetWarehouse, $qty, $description, $additionalData);

        //Update product delivered qty
        $OrderProductItem->updateDeliveredQty();

        //save changes
        if ($toggleOrderStatus) {
            if ($this->isCompletelyDelivered())
                $this->setpo_status(MDN_Purchase_Model_Order::STATUS_COMPLETE);
        }
    }

    /**
     * Return order product item from Product Id
     *
     * @param unknown_type $productId
     */
    public function getOrderProductItem($productId) {
        foreach ($this->getProducts() as $orderProduct) {
            if ($orderProduct->getpop_product_id() == $productId)
                return $orderProduct;
        }

        return null;
    }

    /**
     * Return target warehouse
     */
    public function getTargetWarehouse() {
        $warehouseId = $this->getpo_target_warehouse();
        $warehouse = mage::getModel('AdvancedStock/Warehouse')->load($warehouseId);
        return $warehouse;
    }

    /**
     * Method to define il a field value has changed
     *
     * @param unknown_type $fieldname
     * @return unknown
     */
    protected function fieldHasChanged($fieldname) {
        if ($this->getData($fieldname) != $this->getOrigData($fieldname))
            return true;
        else
            return false;
    }

    //*******************************************************************************************************************************************
    //*******************************************************************************************************************************************
    // Free carriage, order mini
    //*******************************************************************************************************************************************
    //*******************************************************************************************************************************************

    /**
     * Return true if order fullfill supplier's free carriag weight
     */
    public function isFreeCarriageForWeight() {
        $minWeight = $this->getSupplier()->getsup_free_carriage_weight();
        if (($minWeight == '') || ($minWeight == 0))
            return true;

        $orderWeight = $this->getWeight();
        return ($orderWeight >= $minWeight);
    }

    /**
     * Return true if order fullfill supplier's free carriag amount
     */
    public function isFreeCarriageForAmount() {
        $minAmount = $this->getSupplier()->getsup_free_carriage_amount();
        if (($minAmount == '') || ($minAmount == 0))
            return true;

        $orderAmount = $this->getProductTotalBase();

        return ($orderAmount >= $minAmount);
    }

    /**
     * Return true if order fullfill supplier's minimum amount
     */
    public function reachOrderMinimumAmount() {
        $minAmount = $this->getSupplier()->getsup_order_mini();
        if (($minAmount == '') || ($minAmount == 0))
            return true;

        $orderAmount = $this->getProductTotalBase();

        return ($orderAmount >= $minAmount);
    }

    /**
     * Rturn invoice du date
     */
    public function getInvoiceDueDate()
    {
        $invoiceDate = $this->getpo_invoice_date();
        if ($invoiceDate)
        {
            $paymentDelay = $this->getSupplier()->getsup_payment_delay();
            $invoiceTimeStamp = strtotime($invoiceDate);
            $dueDateTimeStamp = $invoiceTimeStamp + $paymentDelay * 24 * 3600;
            return date('Y-m-d', $dueDateTimeStamp);
        }

        return null;
    }
}