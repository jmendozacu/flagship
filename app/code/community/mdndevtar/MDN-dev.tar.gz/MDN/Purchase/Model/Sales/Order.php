<?php

/*
 * This class is not used
 * Only for backward compatibility with previous ERP versions
 *
 */

class MDN_Purchase_Model_Sales_Order extends Mage_Sales_Model_Order
{

}