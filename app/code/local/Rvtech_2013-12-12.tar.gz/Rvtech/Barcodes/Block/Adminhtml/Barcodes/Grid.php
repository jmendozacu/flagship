<?php
class Rvtech_Barcodes_Block_Adminhtml_Barcodes_Grid extends Mage_Adminhtml_Block_Widget_Grid
{
   protected $_proURL; 
   public function __construct()
   {
       parent::__construct();
       $this->setId('codesGrid');
       $this->setDefaultSort('id');
       $this->setDefaultDir('DESC');
       $this->setSaveParametersInSession(true);
   }
   protected function _prepareCollection()
   {
      $collection = Mage::getModel('barcodes/barcodes')->getCollection();
     // echo "<pre>";print_r($collection->getData());
      foreach ($collection as $colval) {
           $productcollection = Mage::getModel('catalog/product')->load($colval->getProductId());
           $productName = $productcollection->getName();
           //$this->_proURL = $productcollection->getProductUrl();
           $UPC = $productcollection->getUpc();
           $colval->setProductName($productName);
           $colval->setAction($productName);
           $colval->setUpc($UPC);
           $newDateFormat = Mage::app()->getLocale()->date(strtotime($colval->getDate()), null, null, false)->toString('MMM d, Y');
           $colval->setDate($newDateFormat);
           $colval->setSku($productcollection->getSku());
           $attributes = Mage::getResourceModel('eav/entity_attribute_collection')
                            ->addFieldToFilter('attribute_code', 'factory') 
                            ->load();
          $attribute = $attributes->getFirstItem();

          $attr = $attribute->getSource()->getAllOptions(true);
          foreach ($attr as $attval) {
              if($attval['value']==$colval->getFactoryId())
               {
                   $factName = $attval['label'];
                   $colval->setFactoryId($factName);
                }
            }
      }
      $this->setCollection($collection);
      return parent::_prepareCollection();
    }
   protected function _prepareColumns()
   {
       $this->addColumn('id',
             array(
                    'header' => 'ID',
                    'align' =>'right',
                    'width' => '50px',
                    'index' => 'id',
               ));
       $this->addColumn('date', array(
                    'header' => 'Date Ordered',
                    'align' =>'left',
                    'index' => 'date',
             ));
        $this->addColumn('factory_id', array(
                     'header' => 'Factory',
                     'align' =>'left',
                     'index' => 'factory_id',
          ));
        $this->addColumn('purchase_order',
               array(
                    'header' => 'Purchase Order (Invoice #)',
                    'align' =>'left',
                    'index' => 'purchase_order',
              ));
        $this->addColumn('product_id', array(
                    'header' => 'Product ID',
                    'align' =>'left',
                    'index' => 'product_id',
             ));
        $this->addColumn('sku', array(
                     'header' => 'SKU',
                     'align' =>'left',
                     'index' => 'sku',
          ));
        $this->addColumn('product_name', array(
                    'header' => 'Product Name',
                    'align' =>'left',
                    'index' => 'product_name',
                    'renderer' =>  'Rvtech_Barcodes_Block_Adminhtml_Barcodes_Renderer_ProductRender',
             ));
        $this->addColumn('upc',
               array(
                    'header' => 'UPC',
                    'align' =>'left',
                    'index' => 'upc',
              ));
        $this->addColumn('dzv_serial', array(
                    'header' => 'DZV Serial',
                    'align' =>'left',
                    'index' => 'dzv_serial',
             ));
        /*$this->addColumn('action',
        array(
            'header'    =>  'Action',
            'width'     => '100',
            'type'      => 'action',
            'getter'    => 'getproduct_id',
            'actions'   => array(
                 array(
                            'caption'   => 'View',
                            'url'     => array(
                            'base'=>'catalog/product/view/id',
                        //'params'=>array('store'=>$this->getRequest()->getParam('store'))
                    ),
                    'field'   => 'id'
                )
            ),
            'filter'    => false,
            'sortable'  => false,
            'index'     => 'stores',
            'is_system' => true,
    ));*/
         $this->addExportType('*/*/exportCsv', 'CSV');
        $this->addExportType('*/*/exportXml', 'Excel XML');
         return parent::_prepareColumns();
    }
    public function getRowUrl($row)
    {
         return $this->getUrl('*/*/edit', array('id' => $row->getId()));
    }

}