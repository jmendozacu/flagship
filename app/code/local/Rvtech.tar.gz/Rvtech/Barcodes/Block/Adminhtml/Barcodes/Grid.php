<?php
class Rvtech_Barcodes_Block_Adminhtml_Barcodes_Grid extends Mage_Adminhtml_Block_Widget_Grid
{
   protected $_proURL; 
   public function __construct()
   {
       parent::__construct();
       $this->setId('codesGrid');
       $this->setDefaultSort('id');
       $this->setDefaultDir('DESC');
       $this->setSaveParametersInSession(true);
   }
   protected function _prepareCollection()
   {
      $collection = Mage::getModel('barcodes/barcodes')->getCollection();
      if($this->getRequest()->getParam('poId') && $this->getRequest()->getParam('pId')){
          $poId = $this->getRequest()->getParam('poId');
          $pId = $this->getRequest()->getParam('pId');
          $collection->addFieldToFilter('purchase_order', array('eq' => $poId))
                    ->addFieldToFilter('product_id', array('eq' => $pId));
      }
      $this->setCollection($collection);
      return parent::_prepareCollection();
    }
   protected function _prepareColumns()
   {
       $this->addColumn('id',
             array(
                    'header' => 'ID',
                    'align' =>'right',
                    'width' => '50px',
                    'index' => 'id',
               ));
       $this->addColumn('date', array(
                    'header' => 'Date Ordered',
                    'align' =>'left',
                    'index' => 'date',
                    'renderer' =>'Rvtech_Barcodes_Block_Adminhtml_Barcodes_Renderer_Product',
             ));
        $this->addColumn('factory_id', array(
                     'header' => 'Factory',
                     'align' =>'left',
                     'index' => 'factory_id',
                     'renderer' =>'Rvtech_Barcodes_Block_Adminhtml_Barcodes_Renderer_Product',
          ));
        $this->addColumn('purchase_order',
               array(
                    'header' => 'Purchase Order (Invoice #)',
                    'align' =>'left',
                    'index' => 'purchase_order',
              ));
        $this->addColumn('product_id', array(
                    'header' => 'Product ID',
                    'align' =>'left',
                    'index' => 'product_id',
             ));
        $this->addColumn('sku', array(
                     'header' => 'SKU',
                     'align' =>'left',
                     'index' => 'sku',
                     'renderer' =>'Rvtech_Barcodes_Block_Adminhtml_Barcodes_Renderer_Product',
          ));
        $this->addColumn('product_name', array(
                    'header' => 'Product Name',
                    'align' =>'left',
                    'index' => 'product_name',
                    'renderer' =>  'Rvtech_Barcodes_Block_Adminhtml_Barcodes_Renderer_ProductRender',
             ));
        $this->addColumn('upc',
               array(
                    'header' => 'UPC',
                    'align' =>'left',
                    'index' => 'upc',
                    'renderer' =>'Rvtech_Barcodes_Block_Adminhtml_Barcodes_Renderer_Product',
              ));
        $this->addColumn('dzv_serial', array(
                    'header' => 'DZV Serial',
                    'align' =>'left',
                    'index' => 'dzv_serial',
             ));
        
        $this->addExportType('*/*/exportCsv', 'CSV');
        $this->addExportType('*/*/exportXml', 'Excel XML');
         return parent::_prepareColumns();
    }
    public function getRowUrl($row)
    {
         return $this->getUrl('*/*/edit', array('id' => $row->getId()));
    }

}