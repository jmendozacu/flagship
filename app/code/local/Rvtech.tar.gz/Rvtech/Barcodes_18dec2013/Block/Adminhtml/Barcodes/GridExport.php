<?php
class Rvtech_Barcodes_Block_Adminhtml_Barcodes_GridExport extends Mage_Adminhtml_Block_Widget_Grid
{
   
   public function __construct()
   {
       parent::__construct();
       $this->setId('codesGrid');
       $this->setDefaultSort('id');
       $this->setDefaultDir('DESC');
       $this->setSaveParametersInSession(true);
   }
   protected function _prepareCollection()
   {
      $collection = Mage::getModel('barcodes/barcodes')->getCollection();
  
      foreach ($collection as $colval) {

           $productcollection = Mage::getModel('catalog/product')->load($colval->getProductId());
           $productName = $productcollection->getName();
           if($productcollection->getImage() != "no_selection")
           {
              $imageUrl = Mage::getModel('catalog/product_media_config')->getMediaUrl($productcollection->getImage());
           }else
           {
              $imageUrl = $productcollection->getImage();
           }

           $UPC = $productcollection->getUpc();
           $colval->setProductName($productName);
           $colval->setAction($productName);
           $colval->setUpc($UPC);
           $colval->setWeight($productcollection->getWeight());
           $colval->setActualWeight($productcollection->getActualWeight());
           $colval->setSize($productcollection->getHoodWidthInches());
           $colval->setHeight($productcollection->getHeight());
           $colval->setLength($productcollection->getLength());
           $colval->setWidth($productcollection->getWidth());
           $colval->setImageUrl($imageUrl);
           $newDateFormat = Mage::app()->getLocale()->date(strtotime($colval->getDate()), null, null, false)->toString('MMM d, Y');
           $colval->setDate($newDateFormat);
           $colval->setSku($productcollection->getSku());
           $attributesCfm = Mage::getResourceModel('eav/entity_attribute_collection')
                            ->addFieldToFilter('attribute_code', 'cfm') 
                            ->load();
          $attributeCfm = $attributesCfm->getFirstItem();

          $attrCfm = $attributeCfm->getSource()->getAllOptions(true);

          foreach ($attrCfm as $attrCfmval) {
              if($attrCfmval['value']==$productcollection->getCfm())
               {
                   $CfmName = $attrCfmval['label'];
                    $colval->setCfm($CfmName);
                }
            }
           $attributes = Mage::getResourceModel('eav/entity_attribute_collection')
                            ->addFieldToFilter('attribute_code', 'factory') 
                            ->load();
          $attribute = $attributes->getFirstItem();

          $attr = $attribute->getSource()->getAllOptions(true);

          foreach ($attr as $attval) {
              if($attval['value']==$colval->getFactoryId())
               {
                   $factName = $attval['label'];
                   $colval->setFactoryId($factName);
                }
            }
      }
      

      $this->setCollection($collection);
      return parent::_prepareCollection();
    }
   protected function _prepareColumns()
   {
       $this->addColumn('id',
             array(
                    'header' => 'ID',
                    'align' =>'right',
                    'width' => '50px',
                    'index' => 'id',
               ));
       $this->addColumn('date', array(
                    'header' => 'Date Ordered',
                    'align' =>'left',
                    'index' => 'date',
             ));
        $this->addColumn('factory_id', array(
                     'header' => 'Factory',
                     'align' =>'left',
                     'index' => 'factory_id',
          ));
        $this->addColumn('purchase_order',
               array(
                    'header' => 'Purchase Order (Invoice #)',
                    'align' =>'left',
                    'index' => 'purchase_order',
              ));
        $this->addColumn('product_id', array(
                    'header' => 'Product ID',
                    'align' =>'left',
                    'index' => 'product_id',
             ));
        $this->addColumn('sku', array(
                     'header' => 'SKU',
                     'align' =>'left',
                     'index' => 'sku',
          ));
        $this->addColumn('product_name', array(
                    'header' => 'Product Name',
                    'align' =>'left',
                    'index' => 'product_name',
             ));
        $this->addColumn('upc',
               array(
                    'header' => 'UPC',
                    'align' =>'left',
                    'index' => 'upc',
              ));
        $this->addColumn('dzv_serial', array(
                    'header' => 'DZV Serial',
                    'align' =>'left',
                    'index' => 'dzv_serial',
             ));
        $this->addColumn('weight', array(
                    'header' => 'Weight',
                    'align' =>'left',
                    'index' => 'weight',
             ));
        $this->addColumn('actual_weight', array(
                    'header' => 'Actual Weight',
                    'align' =>'left',
                    'index' => 'actual_weight',
             ));
        $this->addColumn('size', array(
                    'header' => 'Size',
                    'align' =>'left',
                    'index' => 'size',
             ));
        $this->addColumn('height', array(
                    'header' => 'Height',
                    'align' =>'left',
                    'index' => 'height',
             ));
        $this->addColumn('width', array(
                    'header' => 'Width',
                    'align' =>'left',
                    'index' => 'width',
             ));
        $this->addColumn('length', array(
                    'header' => 'Length',
                    'align' =>'left',
                    'index' => 'length',
             ));
        $this->addColumn('cfm', array(
                    'header' => 'CFM',
                    'align' =>'left',
                    'index' => 'cfm',
             ));
        $this->addColumn('image_url', array(
                    'header' => 'Main Image Url',
                    'align' =>'left',
                    'index' => 'image_url',
             ));
         return parent::_prepareColumns();
    }

}