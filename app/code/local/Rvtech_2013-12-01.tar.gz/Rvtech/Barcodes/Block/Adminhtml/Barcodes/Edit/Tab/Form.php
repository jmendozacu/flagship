<?php

class Rvtech_Barcodes_Block_Adminhtml_Barcodes_Edit_Tab_Form extends Mage_Adminhtml_Block_Widget_Form {

	protected function _prepareForm() {
		$form = new Varien_Data_Form();
		$this->setForm($form);
		//$productsku = 'ski';
		$collection = Mage::getModel('catalog/product')
				->getCollection()
				->addAttributeToSelect('*')
				->addAttributeToFilter('status', 1)
				->addAttributeToSort('sku', 'ASC');

		$productarr[null] = '';
		$productsku[null] = '';
		foreach ($collection as $product) {
			$productarr[$product->getId()] = $product->getSku() . ' - ' . $product->getName();
			if($product->getUpc()) {
				$productsku[$product->getUpc()] = $product->getId();
			}
		}
		
		//print_r($killjson);exit(); 
		$attributes = Mage::getResourceModel('eav/entity_attribute_collection')
				->addFieldToFilter('attribute_code', 'factory')
				->load();
		$attribute = $attributes->getFirstItem();

		$attr = $attribute->getSource()->getAllOptions(true);

		foreach ($attr as $attval) {
			$factarr[$attval['value']] = $attval['label'];
		}

		$fieldset = $form->addFieldset('barcodes_form', array('legend' => 'Ref information'));
		$fieldset->addField('purchase_order', 'text', array(
			'label' => 'Purchase Order (Invoice #)',
			'class' => 'required-entry',
			'required' => true,
			'name' => 'purchase_order',
		));
		$fieldset->addField('date', 'date', array(
			'label' => 'Order Date',
			'class' => 'required-entry',
			'required' => true,
			'name' => 'date',
			'image' => $this->getSkinUrl('images/grid-cal.gif'),
			//'format'=> Mage::app()->getLocale()->getDateFormat(Mage_Core_Model_Locale::FORMAT_TYPE_SHORT)
			'format' => 'yyyy-M-d',
		));
		$fieldset->addField('factory_id', 'select', array(
			'label' => 'Factory',
			'class' => 'required-entry',
			'required' => true,
			'name' => 'factory_id',
			'values' => $factarr,
		));
		$fieldset->addField('upc', 'text', array(
			'label' => 'UPC',
			'name' => 'upc',
			'class' => 'required-entry',
			'required' => false,
			'onchange' => 'validateUPC(this.value)',
		))->setAfterElementHtml("<script type=\"text/javascript\">
			var productSel = " . json_encode($productsku) . ";
			function validateUPC(selectElement) {
				console.log(\"selecting product from UPC \" + selectElement);
				if(selectElement != '') {
					document.getElementById('product_id').value = productSel[selectElement];
					//document.getElementById('upc').select();
				}
			}
		</script>");
		$fieldset->addField('product_id', 'select', array(
			'label' => 'Product',
			'class' => 'required-entry',
			'required' => true,
			'name' => 'product_id',
			'values' => $productarr,
		));
		/* $fieldset->addField('factory_serial', 'text',
		  array(
		  'label' => 'Factory Serial',
		  'name' => 'factory_serial',
		  )); */
		//if(!Mage::registry('barcodes_data')->getId())
		//{
		$fieldset->addField('sequence', 'text', array(
			'label' => 'Quantity',
			'name' => 'sequence',
			'class' => 'validate-digits validate-digits-range digits-range-0000-9999',
		));
		//}
		$form->addField('note', 'note', array(
			'text' => 'Note: A unique barcode will be generated for each quantity of this product. The default quantity is 1.'
		));

		$barcodes_data = Mage::registry('barcodes_data')->getData();
		if (!empty($barcodes_data)) {

			$form->setValues($barcodes_data);
		}
		return parent::_prepareForm();
	}

}