<?php
class Rvtech_Barcodes_Adminhtml_BarcodesController extends Mage_Adminhtml_Controller_Action
{
    protected function _initAction()
    {
        $this->loadLayout()->_setActiveMenu('barcodes/set_time')
                ->_addBreadcrumb('Barcode Manager','Barcode Manager');
       return $this;
     }
      public function indexAction()
      {
         $this->_initAction();
         $this->renderLayout();
         $handle = Mage::getSingleton('core/layout')->getUpdate()->getHandles();
		 //echo "<pre>"; print_r($handle); echo "</pre>";

      }
      public function editAction()
      {
           $barcodeId = $this->getRequest()->getParam('id');
           $barcodeModel = Mage::getModel('barcodes/barcodes')->load($barcodeId);
           if ($barcodeModel->getId() || $barcodeId == 0)
           {
             Mage::register('barcodes_data', $barcodeModel);
             $this->loadLayout();
             $this->_setActiveMenu('barcodes/set_time');
             $this->_addBreadcrumb('Barcode Manager', 'Barcode Manager');
             $this->_addBreadcrumb('Barcode Description', 'Barcode Description');
             $this->getLayout()->getBlock('head')
                  ->setCanLoadExtJs(true);
             $this->_addContent($this->getLayout()
                  ->createBlock('barcodes/adminhtml_barcodes_edit'))
                  ->_addLeft($this->getLayout()
                  ->createBlock('barcodes/adminhtml_barcodes_edit_tabs')
              );
             $this->renderLayout();
           }
           else
           {
                 Mage::getSingleton('adminhtml/session')
                       ->addError('Barcode does not exist');
                 $this->_redirect('*/*/');
            }
       }
       public function newAction()
       {
          $this->_forward('edit');
       }
       public function saveAction()
       {
         if ($this->getRequest()->getPost())
         {
           try {
                 $postData = $this->getRequest()->getPost();

                  $productId = $this->getRequest()->getParam('product');
                  $productcollection = Mage::getModel('catalog/product')->load($productId);
                  $productName = $productcollection->getName();
                  $quantityval = $this->getRequest()->getParam('quantity');
                  if($quantityval!="")
                  {
                    $quantity = $quantityval;
                  }else{
                    $quantity = 1;
                  }
                  

                 $barcodeModel = Mage::getModel('barcodes/barcodes');
                 $barcode = $this->getRequest()->getParam('product').'-'.$this->getRequest()->getParam('date').
                 '-'.$this->getRequest()->getParam('factory').'-'.$this->getRequest()->getParam('purchase_order');
                 
                  $barcodeModel
                    ->addData($postData)
                    ->setBarcode($barcode)
                    ->setProductName($productName)
                    ->setQuantity($quantity)
                    ->setId($this->getRequest()->getParam('id'))
                    ->save();
                 Mage::getSingleton('adminhtml/session')
                               ->addSuccess('successfully saved');
                 Mage::getSingleton('adminhtml/session')
                                ->settestData(false);
                 $this->_redirect('*/*/');
                return;
          } catch (Exception $e){
                Mage::getSingleton('adminhtml/session')
                                  ->addError($e->getMessage());
                Mage::getSingleton('adminhtml/session')
                 ->settestData($this->getRequest()
                                    ->getPost()
                );
                $this->_redirect('*/*/edit',
                            array('id' => $this->getRequest()
                                                ->getParam('id')));
                return;
                }
              }
              $this->_redirect('*/*/');
            }
          public function deleteAction()
          {
              if($this->getRequest()->getParam('id') > 0)
              {
                try
                {
                    $barcodeModel = Mage::getModel('barcodes/barcodes');
                    $barcodeModel->setId($this->getRequest()
                                        ->getParam('id'))
                              ->delete();
                    Mage::getSingleton('adminhtml/session')
                               ->addSuccess('successfully deleted');
                    $this->_redirect('*/*/');
                 }
                 catch (Exception $e)
                  {
                           Mage::getSingleton('adminhtml/session')
                                ->addError($e->getMessage());
                           $this->_redirect('*/*/edit', array('id' => $this->getRequest()->getParam('id')));
                  }
             }
            $this->_redirect('*/*/');
       }
}
?>