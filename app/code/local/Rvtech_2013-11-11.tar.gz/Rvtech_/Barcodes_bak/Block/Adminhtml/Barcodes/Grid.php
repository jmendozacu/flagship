<?php
class Rvtech_Barcodes_Block_Adminhtml_Barcodes_Grid extends Mage_Adminhtml_Block_Widget_Grid
{
   public function __construct()
   {
       parent::__construct();
       $this->setId('codesGrid');
       $this->setDefaultSort('id');
       $this->setDefaultDir('DESC');
       $this->setSaveParametersInSession(true);
   }
   protected function _prepareCollection()
   {
      $collection = Mage::getModel('barcodes/barcodes')->getCollection();
      $this->setCollection($collection);
      return parent::_prepareCollection();
    }
   protected function _prepareColumns()
   {
       $this->addColumn('id',
             array(
                    'header' => 'ID',
                    'align' =>'right',
                    'width' => '50px',
                    'index' => 'id',
               ));
       $this->addColumn('purchase_order',
               array(
                    'header' => 'Purchase Order (Invoice #)',
                    'align' =>'left',
                    'index' => 'purchase_order',
              ));
       $this->addColumn('date', array(
                    'header' => 'Date',
                    'align' =>'left',
                    'index' => 'date',
             ));
        $this->addColumn('factory', array(
                     'header' => 'Factory',
                     'align' =>'left',
                     'index' => 'factory',
          ));
        $this->addColumn('product_name', array(
                    'header' => 'Product',
                    'align' =>'left',
                    'index' => 'product_name',
             ));
        $this->addColumn('quantity', array(
                    'header' => 'Quantity',
                    'align' =>'left',
                    'index' => 'quantity',
             ));
        $this->addColumn('barcode', array(
                    'header' => 'Barcode',
                    'align' =>'left',
                    'index' => 'barcode',
             ));
         return parent::_prepareColumns();
    }
    public function getRowUrl($row)
    {
         return $this->getUrl('*/*/edit', array('id' => $row->getId()));
    }
}