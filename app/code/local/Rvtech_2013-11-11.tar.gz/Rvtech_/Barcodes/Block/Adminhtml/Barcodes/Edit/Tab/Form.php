<?php
class Rvtech_Barcodes_Block_Adminhtml_Barcodes_Edit_Tab_Form extends Mage_Adminhtml_Block_Widget_Form
{
   protected function _prepareForm()
   {
       $form = new Varien_Data_Form();
       $this->setForm($form);
       $collection = Mage::getModel('catalog/product')
                        ->getCollection()
                        ->addAttributeToSelect('*')
                        ->addAttributeToFilter('status', 1)
                        ->addAttributeToFilter('type_id', 'simple')
                        ->addAttributeToSort('name', 'ASC');
                        
         $productarr[null] = '';                
        foreach ($collection as $product) {
         $productarr[$product->getId()] = $product->getName();
          }

          $attributes = Mage::getResourceModel('eav/entity_attribute_collection')
                            ->addFieldToFilter('attribute_code', 'factory') 
                            ->load();
          $attribute = $attributes->getFirstItem();

          $attr = $attribute->getSource()->getAllOptions(true);
          
          foreach ($attr as $attval) {
             $factarr[$attval['value']] = $attval['label'];
           }
         //echo "<pre>";print_r($productarr);exit;
      
       $fieldset = $form->addFieldset('barcodes_form',
                                       array('legend'=>'Ref information'));
        $fieldset->addField('purchase_order', 'text',
                       array(
                          'label' => 'Purchase Order (Invoice #)',
                          'class' => 'required-entry',
                          'required' => true,
                          'name' => 'purchase_order',
                    ));
        $fieldset->addField('date', 'date',
                       array(
                        'label' => 'Date',
                        'class' => 'required-entry',
                        'required' => true,
                        'name' => 'date',
                        'image'=> $this->getSkinUrl('images/grid-cal.gif'),
                        //'format'=> Mage::app()->getLocale()->getDateFormat(Mage_Core_Model_Locale::FORMAT_TYPE_SHORT)
                         'format'    => 'yyyy-M-d',
                    ));
          $fieldset->addField('factory_id', 'select',
                    array(
                        'label' => 'Factory',
                        'class' => 'required-entry',
                        'required' => true,
                        'name' => 'factory_id',
                        'values' => $factarr,
                 ));
          $fieldset->addField('product_id', 'select',
                    array(
                        'label' => 'Product',
                        'class' => 'required-entry',
                        'required' => true,
                        'name' => 'product_id',
                        'values' => $productarr,
                 ));
           $fieldset->addField('factory_serial', 'text',
                       array(
                          'label' => 'Factory Serial',
                          'name' => 'factory_serial',
                    ));

           if(!Mage::registry('barcodes_data')->getId())
             {
            $fieldset->addField('sequence', 'text',
                      array(
                          'label' => 'Quantity',
                          'name' => 'sequence',
                          'class' => 'validate-digits validate-digits-range digits-range-0-100',
                   ));
            }
          $form->addField('note', 'note', array(
          'text'     => 'Note: A unique barcode will be generated for each quantity of this product. The default quantity is 1.'
        ));

 $barcodes_data = Mage::registry('barcodes_data')->getData();         
 if ( !empty($barcodes_data) )
 {

    $form->setValues($barcodes_data);
 }
  return parent::_prepareForm();
 }
}