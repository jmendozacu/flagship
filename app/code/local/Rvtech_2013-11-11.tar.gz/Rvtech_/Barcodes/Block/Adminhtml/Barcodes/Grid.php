<?php
class Rvtech_Barcodes_Block_Adminhtml_Barcodes_Grid extends Mage_Adminhtml_Block_Widget_Grid
{
   public function __construct()
   {
       parent::__construct();
       $this->setId('codesGrid');
       $this->setDefaultSort('id');
       $this->setDefaultDir('DESC');
       $this->setSaveParametersInSession(true);
   }
   protected function _prepareCollection()
   {
      $collection = Mage::getModel('barcodes/barcodes')->getCollection();

      foreach ($collection as $colval) {
           $productcollection = Mage::getModel('catalog/product')->load($colval->getProductId());
           $productName = $productcollection->getName();
           $colval->setProductId($productName);
           $attributes = Mage::getResourceModel('eav/entity_attribute_collection')
                            ->addFieldToFilter('attribute_code', 'factory') 
                            ->load();
          $attribute = $attributes->getFirstItem();

          $attr = $attribute->getSource()->getAllOptions(true);
          foreach ($attr as $attval) {
              if($attval['value']==$colval->getFactoryId())
               {
                   $factName = $attval['label'];
                   $colval->setFactoryId($factName);
                }
            }
      }
      //echo "<pre>";print_r($collection->getData());
      $this->setCollection($collection);
      return parent::_prepareCollection();
    }
   protected function _prepareColumns()
   {
       $this->addColumn('id',
             array(
                    'header' => 'ID',
                    'align' =>'right',
                    'width' => '50px',
                    'index' => 'id',
               ));
       $this->addColumn('purchase_order',
               array(
                    'header' => 'Purchase Order (Invoice #)',
                    'align' =>'left',
                    'index' => 'purchase_order',
              ));
       $this->addColumn('date', array(
                    'header' => 'Date',
                    'align' =>'left',
                    'index' => 'date',
             ));
        $this->addColumn('factory_id', array(
                     'header' => 'Factory',
                     'align' =>'left',
                     'index' => 'factory_id',
          ));
        $this->addColumn('product_id', array(
                    'header' => 'Product',
                    'align' =>'left',
                    'index' => 'product_id',
             ));
        $this->addColumn('barcode', array(
                    'header' => 'Barcode',
                    'align' =>'left',
                    'index' => 'barcode',
             ));
         return parent::_prepareColumns();
    }
    public function getRowUrl($row)
    {
         return $this->getUrl('*/*/edit', array('id' => $row->getId()));
    }
}