<?php
class Rvtech_Barcodes_Adminhtml_BarcodesController extends Mage_Adminhtml_Controller_Action
{
    protected function _initAction()
    {
        $this->loadLayout()->_setActiveMenu('barcodes/set_time')
                ->_addBreadcrumb('Barcode Manager','Barcode Manager');
       return $this;
     }
      public function indexAction()
      {
         $this->_initAction();
         $this->renderLayout();
         $handle = Mage::getSingleton('core/layout')->getUpdate()->getHandles();
     //echo "<pre>"; print_r($handle); echo "</pre>";

      }
      public function editAction()
      {
           $barcodeId = $this->getRequest()->getParam('id');
           $barcodeModel = Mage::getModel('barcodes/barcodes')->load($barcodeId);
           if ($barcodeModel->getId() || $barcodeId == 0)
           {
             Mage::register('barcodes_data', $barcodeModel);
             $this->loadLayout();
             $this->_setActiveMenu('barcodes/set_time');
             $this->_addBreadcrumb('Barcode Manager', 'Barcode Manager');
             $this->_addBreadcrumb('Barcode Description', 'Barcode Description');
             $this->getLayout()->getBlock('head')
                  ->setCanLoadExtJs(true);
             $this->_addContent($this->getLayout()
                  ->createBlock('barcodes/adminhtml_barcodes_edit'))
                  ->_addLeft($this->getLayout()
                  ->createBlock('barcodes/adminhtml_barcodes_edit_tabs')
              );
             $this->renderLayout();
           }
           else
           {
                 Mage::getSingleton('adminhtml/session')
                       ->addError('Barcode does not exist');
                 $this->_redirect('*/*/');
            }
       }
       public function newAction()
       {
          $this->_forward('edit');
       }
       public function saveAction()
       {
         if ($this->getRequest()->getPost())
         {
           try {
                 $postData = $this->getRequest()->getPost();
                 
                  $quantityval = $this->getRequest()->getParam('sequence');
                  $dzvserial = $this->getRequest()->getParam('dzv_serial');
                  if($quantityval!="")
                  {
                    $quantity = $quantityval;
                  }else{
                    $quantity = 1;
                  }
      
                 
         //echo "<pre>";print_r($factarr);exit;
                $barcodeexist = $this->getRequest()->getParam('purchase_order').'-'.$this->getRequest()->getParam('date').
                 '-'.$this->getRequest()->getParam('product_id');
                 $barcodeModel = Mage::getModel('barcodes/barcodes');
                 $collectionexist = Mage::getModel('barcodes/barcodes')
                        ->getCollection()
                        ->addFieldToFilter('barcode', array("like"=>$barcodeexist.'%'))
                        ->setOrder('sequence', 'DESC');
                  $lastrecord = $collectionexist->getFirstItem();
                //echo "<pre>";print_r($lastrecord->getData());
                    //  echo $lastrecord->getBarcode(); 
                  if($lastrecord->getSequence())
                  {
                      $j = $lastrecord->getSequence()+1;
                      $quantitylast = $lastrecord->getSequence() + $quantity;

                  }else{
                       $j = 1;
                       $quantitylast = $quantity;
                  }
                 for($i = 1;$i <= $quantitylast;$i++)
                 {

      
                    $barcode = $this->getRequest()->getParam('date').'-'.$this->getRequest()->getParam('purchase_order').
                    '-'.$this->getRequest()->getParam('factory_id').'-'.$this->getRequest()->getParam('product_id').'-'.$i;
                    $barcodeModel
                      ->addData($postData)
                      ->setSequence($i)
                      ->setFactorySerial($this->getRequest()->getParam('factory_serial'))
                      ->setId($this->getRequest()->getParam('id'));
                      if(!$this->getRequest()->getParam('id'))
                      {
                       $barcodeModel->setBarcode($barcode);
                                    
                      }
                      $barcodeModel->save();
                  }

                 Mage::getSingleton('adminhtml/session')
                               ->addSuccess('successfully saved');
                 Mage::getSingleton('adminhtml/session')
                                ->settestData(false);
                 $this->_redirect('*/*/');
                return;
          } catch (Exception $e){
                Mage::getSingleton('adminhtml/session')
                                  ->addError($e->getMessage());
                Mage::getSingleton('adminhtml/session')
                 ->settestData($this->getRequest()
                                    ->getPost()
                );
                $this->_redirect('*/*/edit',
                            array('id' => $this->getRequest()
                                                ->getParam('id')));
                return;
                }
              }
              $this->_redirect('*/*/');
            }
          public function deleteAction()
          {
              if($this->getRequest()->getParam('id') > 0)
              {
                try
                {
                    $barcodeModel = Mage::getModel('barcodes/barcodes');
                    $barcodeModel->setId($this->getRequest()
                                        ->getParam('id'))
                              ->delete();
                    Mage::getSingleton('adminhtml/session')
                               ->addSuccess('successfully deleted');
                    $this->_redirect('*/*/');
                 }
                 catch (Exception $e)
                  {
                           Mage::getSingleton('adminhtml/session')
                                ->addError($e->getMessage());
                           $this->_redirect('*/*/edit', array('id' => $this->getRequest()->getParam('id')));
                  }
             }
            $this->_redirect('*/*/');
       }
}
?>